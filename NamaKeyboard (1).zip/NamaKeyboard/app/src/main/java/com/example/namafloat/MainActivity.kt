package com.example.namafloat

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        status = TextView(this).apply { textSize = 18f }
        root.addView(status)

        root.addView(TextView(this).apply {
            text = "\nTombol mengambang 🎲 (nama acak) dan 🎁 (kode referral) mengisi kolom isian yang sedang dipilih di aplikasi atau browser apa pun.\n\n" +
                "Cara mengaktifkan:\n" +
                "1. Ketuk tombol 1. Di halaman yang terbuka, ketuk ⋮ di pojok kanan atas lalu pilih \"Izinkan pengaturan terbatas\" (Android 13 ke atas; kalau menu itu tidak ada, lewati).\n" +
                "2. Ketuk tombol 2, cari \"Nama Acak\", lalu nyalakan.\n" +
                "3. Buka aplikasi lain, ketuk kolom isian, lalu ketuk 🎲 atau 🎁.\n\n" +
                "Tahan 🎁 untuk membuka halaman ini. Ketuk ▾ untuk menyembunyikan tombol. Tombol bisa digeser.\n"
            textSize = 15f
        })

        val etRef = EditText(this).apply {
            hint = "Kode referral"
            setText(Prefs.getRef(this@MainActivity))
            setSingleLine(true)
        }
        root.addView(etRef)

        root.addView(Button(this).apply {
            text = "Simpan referral"
            setOnClickListener {
                val v = etRef.text.toString().trim()
                if (v.isEmpty()) {
                    Toast.makeText(this@MainActivity, "Kode tidak boleh kosong", Toast.LENGTH_SHORT).show()
                } else {
                    Prefs.setRef(this@MainActivity, v)
                    Toast.makeText(this@MainActivity, "Tersimpan: $v", Toast.LENGTH_SHORT).show()
                }
            }
        })

        root.addView(Button(this).apply {
            text = "1. Buka info aplikasi (izinkan pengaturan terbatas)"
            setOnClickListener {
                val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                i.data = Uri.parse("package:$packageName")
                startActivity(i)
            }
        })

        root.addView(Button(this).apply {
            text = "2. Aktifkan layanan aksesibilitas"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: ""
        status.text = if (enabled.contains("$packageName/"))
            "Status: AKTIF ✅" else "Status: belum aktif"
    }
}
