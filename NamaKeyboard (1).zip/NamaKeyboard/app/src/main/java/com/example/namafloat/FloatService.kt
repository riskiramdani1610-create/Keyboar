package com.example.namafloat

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class FloatService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var overlay: LinearLayout? = null
    private var collapsed = false

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildOverlay()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        removeOverlay()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        removeOverlay()
        super.onDestroy()
    }

    private fun removeOverlay() {
        val o = overlay ?: return
        try {
            wm?.removeView(o)
        } catch (e: Exception) {
        }
        overlay = null
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun circle(label: String, color: String, sizeDp: Int, textSize: Float): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = textSize
        t.gravity = Gravity.CENTER
        t.setTextColor(Color.WHITE)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Color.parseColor(color))
        t.background = bg
        val lp = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        lp.setMargins(0, dp(4), 0, 0)
        t.layoutParams = lp
        return t
    }

    private fun buildOverlay() {
        removeOverlay()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL

        val toggle = circle("▾", "#CC5F6368", 34, 14f)
        val nama = circle("🎲", "#E61A73E8", 52, 24f)
        val ref = circle("🎁", "#E6E0663A", 52, 24f)
        root.addView(toggle)
        root.addView(nama)
        root.addView(ref)

        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = resources.displayMetrics.widthPixels - dp(72)
        p.y = dp(240)

        draggable(toggle, root, p, {
            collapsed = !collapsed
            val vis = if (collapsed) View.GONE else View.VISIBLE
            nama.visibility = vis
            ref.visibility = vis
            toggle.text = if (collapsed) "▴" else "▾"
            wm?.updateViewLayout(root, p)
        }, null)

        draggable(nama, root, p, { fill(Names.make()) }, null)

        draggable(ref, root, p, { fill(Prefs.getRef(this)) }, {
            val i = Intent(this, MainActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        })

        overlay = root
        wm?.addView(root, p)
    }

    private fun draggable(
        v: View,
        root: View,
        p: WindowManager.LayoutParams,
        onTap: () -> Unit,
        onLong: (() -> Unit)?
    ) {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        var longFired = false
        val longRun = Runnable {
            if (!moved) {
                longFired = true
                onLong?.invoke()
            }
        }
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = p.x
                    startY = p.y
                    moved = false
                    longFired = false
                    if (onLong != null) handler.postDelayed(longRun, 700)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (abs(dx) + abs(dy) > dp(8)) {
                        moved = true
                        handler.removeCallbacks(longRun)
                    }
                    if (moved) {
                        p.x = startX + dx.toInt()
                        p.y = startY + dy.toInt()
                        wm?.updateViewLayout(root, p)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longRun)
                    if (!moved && !longFired) onTap()
                }
                MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(longRun)
            }
            true
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    // Mengisi kolom isian yang sedang dipilih dengan teks (menimpa isi lama)
    private fun fill(text: String) {
        val root = rootInActiveWindow
        val node = root?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (node == null) {
            toast("Ketuk kolom isian dulu")
            return
        }
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        var ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (!ok) {
            // Cadangan: pilih semua isi lalu tempel lewat papan klip
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("nama", text))
            val sel = Bundle()
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0)
            sel.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, node.text?.length ?: 0)
            node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel)
            ok = node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        }
        if (!ok) toast("Gagal mengisi kolom ini")
    }
}
