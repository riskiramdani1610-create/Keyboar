package com.example.namafloat

import android.content.Context

object Prefs {
    private const val FILE = "cfg"
    private const val KEY_REF = "ref"
    const val DEFAULT_REF = "MORI_DI1JBR"

    fun getRef(ctx: Context): String =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getString(KEY_REF, DEFAULT_REF) ?: DEFAULT_REF

    fun setRef(ctx: Context, value: String) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putString(KEY_REF, value.trim()).apply()
    }
}
