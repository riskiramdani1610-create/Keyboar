package com.example.namafloat

import kotlin.random.Random

object Names {
    private val F = listOf("Siti","Dewi","Putri","Rina","Sari","Ayu","Intan","Fitri","Wulan","Maya","Citra","Indah","Rani","Nadia","Anisa","Tika","Salsa","Mega","Lestari","Nur","Ratna","Yuni","Dian","Eka","Fani","Gita","Hana","Ika","Jihan","Kartika","Lia","Mira","Nina","Okta","Prita","Qori","Rosa","Sinta","Tari","Utami","Vera","Wati","Yuli","Zahra","Adel","Bella","Cantika","Dina","Elsa","Farah","Gina","Hesti","Icha","Jelita","Kiki","Laras","Melati","Novi","Rahma","Sekar","Tasya","Vina","Amelia","Aulia","Berliana","Cindy","Dwi","Endah","Febi","Gladys","Helena","Ilma","Jasmine","Karina","Lintang","Mawar","Nabila","Olivia","Pipit","Queen","Rizka","Syifa","Tiara","Ulfa","Vania","Windi","Yasmin","Zalfa","Alya","Bunga","Chelsea","Davina","Elisa","Fiona","Gisela","Hanifa","Inara","Julia","Keisha","Livia","Mutiara","Nirmala","Oktavia","Permata","Rosalina","Salma","Talita")

    private val L = listOf("Lestari","Wulandari","Rahayu","Safitri","Anggraini","Damayanti","Fitriani","Handayani","Maharani","Puspita","Permatasari","Oktaviani","Utami","Andriani","Kusumawati","Ningsih","Sulistyowati","Purnamasari","Rahmawati","Susanti","Wahyuni","Yulianti","Septiani","Kartika","Pertiwi","Cahyani","Amalia","Larasati","Novitasari","Aryani","Nuraini","Hartati","Febriani","Maulida","Ramadhani","Salsabila","Azzahra","Putri","Dewi","Sari")

    // 50% dua kata, 50% tiga kata
    fun make(): String {
        val depan = F.random()
        if (Random.nextBoolean()) return "$depan ${L.random()}"
        var tengah = F.random()
        while (tengah == depan) tengah = F.random()
        return "$depan $tengah ${L.random()}"
    }
}
