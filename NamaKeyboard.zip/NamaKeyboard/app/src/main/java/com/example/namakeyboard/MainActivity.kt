package com.example.namakeyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "Nama Keyboard\n\n" +
                "1. Ketuk \"Aktifkan keyboard\" lalu nyalakan Nama Keyboard.\n" +
                "2. Ketuk di kolom isian mana pun, lalu pilih Nama Keyboard.\n" +
                "3. Ketuk 🎲 untuk nama acak, 🎁 untuk kode referral.\n" +
                "4. Ketuk 🌐 untuk kembali ke keyboard biasa."
            textSize = 16f
        })

        val etRef = EditText(this).apply {
            hint = "Kode referral"
            setText(Prefs.getRef(this@MainActivity))
            setSingleLine(true)
        }
        root.addView(etRef)

        root.addView(Button(this).apply {
            text = "Simpan referral"
            setOnClickListener {
                val v = etRef.text.toString().trim()
                if (v.isEmpty()) {
                    Toast.makeText(this@MainActivity, "Kode tidak boleh kosong", Toast.LENGTH_SHORT).show()
                } else {
                    Prefs.setRef(this@MainActivity, v)
                    Toast.makeText(this@MainActivity, "Tersimpan: $v", Toast.LENGTH_SHORT).show()
                }
            }
        })

        root.addView(Button(this).apply {
            text = "1. Aktifkan keyboard"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        })

        root.addView(Button(this).apply {
            text = "2. Pilih keyboard ini"
            setOnClickListener {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }
}
