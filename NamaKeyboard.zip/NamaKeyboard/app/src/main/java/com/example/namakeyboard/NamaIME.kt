package com.example.namakeyboard

import android.inputmethodservice.InputMethodService
import android.os.Build
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button

class NamaIME : InputMethodService() {

    private var btnRef: Button? = null

    override fun onCreateInputView(): View {
        val v = layoutInflater.inflate(R.layout.keyboard_view, null)
        btnRef = v.findViewById(R.id.btnRef)

        v.findViewById<Button>(R.id.btnNama).setOnClickListener {
            replaceAll(Names.make())
        }
        btnRef?.setOnClickListener {
            replaceAll(Prefs.getRef(this))
        }
        v.findViewById<Button>(R.id.btnSpace).setOnClickListener {
            currentInputConnection?.commitText(" ", 1)
        }
        v.findViewById<Button>(R.id.btnDel).setOnClickListener {
            val ic = currentInputConnection ?: return@setOnClickListener
            val sel = ic.getSelectedText(0)
            if (sel != null && sel.isNotEmpty()) ic.commitText("", 1)
            else ic.deleteSurroundingText(1, 0)
        }
        v.findViewById<Button>(R.id.btnEnter).setOnClickListener { pressEnter() }
        v.findViewById<Button>(R.id.btnSwitch).setOnClickListener { switchKeyboard() }
        return v
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        btnRef?.text = "🎁 " + Prefs.getRef(this)
    }

    // Menimpa seluruh isi kolom dengan teks baru
    private fun replaceAll(text: String) {
        val ic = currentInputConnection ?: return
        ic.beginBatchEdit()
        ic.finishComposingText()
        ic.deleteSurroundingText(10000, 10000)
        ic.commitText(text, 1)
        ic.endBatchEdit()
    }

    private fun pressEnter() {
        val ic = currentInputConnection ?: return
        val action = (currentInputEditorInfo?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }
    }

    private fun switchKeyboard() {
        if (Build.VERSION.SDK_INT >= 28 && switchToPreviousInputMethod()) return
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
    }
}
